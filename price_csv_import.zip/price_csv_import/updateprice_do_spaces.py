import pandas as pd
import pymongo
from pymongo import UpdateOne, UpdateMany
from datetime import datetime, timedelta
import time
import sys
from tqdm import tqdm
import os
import requests
from dotenv import load_dotenv
import multiprocessing
from functools import partial
import numpy as np
import argparse
import csv
import os.path
import random
import json
from pymongo.errors import BulkWriteError, ConnectionFailure, ServerSelectionTimeoutError
import boto3
from botocore.client import Config

load_dotenv()

# MongoDB connection settings
MONGO_URI = os.environ.get("MONGO_URI")
if not MONGO_URI:
    print("Error: MONGO_URI environment variable not set in .env file")
    sys.exit(1)

DB_NAME = os.environ.get("DB_NAME", "your_database_name")
#API_URL = os.environ.get("API_URL", "https://api.accessgrantedonline.com")
#API_TOKEN = os.environ.get("API_TOKEN", "")  # Authorization token for API calls
    
CARDS_COLLECTION = "cards"
ALL_SKU_COLLECTION = "allskus"

# Reduced batch size to prevent timeouts
BATCH_SIZE = 500  # Reduced from 1500
MAX_BULK_OPS = 100  # Maximum operations per bulk write

# Checkpoint file for resuming from failures
CHECKPOINT_FILE = "price_update_checkpoint.json"

# Add DigitalOcean Spaces configuration
DO_SPACES_KEY = os.environ.get("DO_SPACES_KEY")
DO_SPACES_SECRET = os.environ.get("DO_SPACES_SECRET")
DO_SPACES_ENDPOINT = os.environ.get("DO_SPACES_ENDPOINT", "https://nyc3.digitaloceanspaces.com")
DO_SPACES_BUCKET = os.environ.get("DO_SPACES_BUCKET")
DO_SPACES_REGION = os.environ.get("DO_SPACES_REGION", "nyc3")

# Add default file path in DO Spaces
DO_SPACES_FILE_PATH = os.environ.get("DO_SPACES_FILE_PATH", "pricing/english-prices.csv")

def connect_to_mongodb(max_retries=5):
    """Connect to MongoDB with retry logic"""
    retry_count = 0
    while retry_count < max_retries:
        try:
            # Add connection pooling settings and increased timeouts
            client = pymongo.MongoClient(
                MONGO_URI,
                maxPoolSize=20,
                connectTimeoutMS=30000,
                socketTimeoutMS=60000,
                serverSelectionTimeoutMS=30000,
                retryWrites=True
            )
            # Force a connection to verify it works
            client.admin.command('ismaster')
            print(f"✅ Successfully connected to MongoDB ({DB_NAME})")
            return client[DB_NAME]
        except Exception as e:
            retry_count += 1
            wait_time = 2 ** retry_count + random.uniform(0, 1)  # Exponential backoff with jitter
            print(f"❌ Connection attempt {retry_count}/{max_retries} failed: {e}")
            print(f"Waiting {wait_time:.2f} seconds before retrying...")
            time.sleep(wait_time)
    
    print(f"Failed to connect after {max_retries} attempts. Exiting.")
    sys.exit(1)

def load_processed_skus(processed_file):
    """Load set of already processed SKUs from CSV file"""
    processed_skus = set()
    if os.path.exists(processed_file):
        try:
            with open(processed_file, 'r') as f:
                reader = csv.reader(f)
                for row in reader:
                    if row and row[0]:  # Skip empty rows
                        processed_skus.add(row[0])
            print(f"Loaded {len(processed_skus)} previously processed SKUs from {processed_file}")
        except Exception as e:
            print(f"Error loading processed SKUs: {e}")
    return processed_skus

def save_processed_skus(processed_skus, processed_file):
    """Save set of processed SKUs to CSV file"""
    try:
        with open(processed_file, 'w', newline='') as f:
            writer = csv.writer(f)
            for sku in processed_skus:
                writer.writerow([sku])
        print(f"Saved {len(processed_skus)} processed SKUs to {processed_file}")
    except Exception as e:
        print(f"Error saving processed SKUs: {e}")

def load_checkpoint():
    """Load processing checkpoint if exists"""
    try:
        if os.path.exists(CHECKPOINT_FILE):
            with open(CHECKPOINT_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
    return {"current_row": 0, "processed_chunks": 0}

def save_checkpoint(current_row, processed_chunks):
    """Save processing checkpoint"""
    try:
        with open(CHECKPOINT_FILE, 'w') as f:
            json.dump({"current_row": current_row, "processed_chunks": processed_chunks}, f)
    except Exception as e:
        print(f"Error saving checkpoint: {e}")

def execute_bulk_operations(collection, operations, description="operations", max_retries=3):
    """Execute bulk operations with retry logic"""
    if not operations:
        return
    
    # Break operations into smaller batches
    for i in range(0, len(operations), MAX_BULK_OPS):
        batch = operations[i:i + MAX_BULK_OPS]
        retry_count = 0
        success = False
        
        while not success and retry_count < max_retries:
            try:
                result = collection.bulk_write(batch, ordered=False)
                success = True
            except (ConnectionFailure, ServerSelectionTimeoutError) as e:
                retry_count += 1
                wait_time = 2 ** retry_count + random.uniform(0, 1)
                print(f"\nConnection error during bulk {description} ({i}/{len(operations)}): {e}")
                print(f"Retrying in {wait_time:.2f} seconds... (Attempt {retry_count}/{max_retries})")
                time.sleep(wait_time)
                # Reconnect to database
                db = connect_to_mongodb()
                collection = db[collection.name]
            except BulkWriteError as e:
                # Log the error but consider it successful if some operations succeeded
                print(f"\nBulk write error: {e.details.get('writeErrors', [])[0:3]}")
                print(f"Continuing with next batch...")
                success = True
            except Exception as e:
                retry_count += 1
                wait_time = 2 ** retry_count
                print(f"\nUnexpected error during bulk {description}: {e}")
                print(f"Retrying in {wait_time:.2f} seconds... (Attempt {retry_count}/{max_retries})")
                time.sleep(wait_time)
        
        # Add a short pause between batches
        time.sleep(0.2)
        
        if not success:
            print(f"Failed to execute bulk {description} after {max_retries} attempts")

def update_prices_from_chunk(chunk, db_connection=None, processed_skus=None):
    """Update prices in MongoDB for a batch of CSV rows, optionally skipping processed SKUs"""
    # Connect to MongoDB if not provided
    if db_connection is None:
        db = connect_to_mongodb()
    else:
        db = db_connection
        
    cards_collection = db[CARDS_COLLECTION]
    all_sku_collection = db[ALL_SKU_COLLECTION]
    
    card_operations = []
    all_sku_operations = []
    
    # Track stats for this chunk
    updated_skus = 0
    skipped_skus = 0
    updated_cards = 0
    
    # Current timestamp for the price update
    timestamp = datetime.utcnow()
    
    # Track newly processed SKUs in this chunk
    newly_processed = set()
    
    for _, row in chunk.iterrows():
        try:
            tcgplayer_id = str(row['TCGplayer Id'])  # This is our SKU
            
            # Skip if already processed
            if processed_skus is not None and tcgplayer_id in processed_skus:
                skipped_skus += 1
                continue
            
            # Extract price data, removing non-numeric characters
            price_fields = {
                'marketPrice': 'TCG Market Price',
                'lowDirect': 'TCG Direct Low',
                'lowPriceWithShipping': 'TCG Low Price With Shipping',
                'lowPrice': 'TCG Low Price',
                'myStorePrice': 'My Store Price'
            }
            
            prices = {}
            for db_field, csv_field in price_fields.items():
                if csv_field in row and pd.notna(row[csv_field]):
                    try:
                        # Convert to string, remove non-numeric chars except periods, and parse to float
                        clean_price = str(row[csv_field]).replace('$', '').strip()
                        # Replace empty string with 0
                        if clean_price == '':
                            prices[db_field] = None
                        else:
                            price_value = float(clean_price.replace(',', ''))
                            # No longer converting 0 to None
                            prices[db_field] = price_value
                    except (ValueError, TypeError):
                        prices[db_field] = None
                else:
                    prices[db_field] = None
            
            # Determine cTCG value using the fallback logic
            cTCG = (prices['marketPrice'] or prices['lowDirect'] or 
                    prices['lowPriceWithShipping'] or prices['lowPrice'] or 
                    prices['myStorePrice'] or 0)
            
            # Update allskus collection
            update_data = {
                'marketPrice': prices['marketPrice'],
                'lowDirect': prices['lowDirect'],
                'lowPriceWithShipping': prices['lowPriceWithShipping'],
                'lowPrice': prices['lowPrice'],
                'lastPriceUpdate': timestamp
            }
            
            all_sku_operations.append(
                UpdateOne(
                    {'sku': tcgplayer_id},
                    {'$set': update_data}
                )
            )
            updated_skus += 1
            
            # Add to processed set
            if processed_skus is not None:
                newly_processed.add(tcgplayer_id)
            
            # Update all cards with this SKU
            priced = cTCG > 0
            
            card_operations.append(
                UpdateMany(
                    {'sku': tcgplayer_id},
                    {'$set': {
                        'cTCG': cTCG,
                        'priced': priced,
                        'priceUpdatedAt': timestamp
                    }}
                )
            )
            
            # Count how many card documents would be updated
            updated_cards += 1
            
        except Exception as e:
            product_name = row.get('Product Name', 'Unknown product')
            print(f"\nError processing {product_name}: {e}")
    
    # Execute bulk operations in smaller batches with retry logic
    execute_bulk_operations(all_sku_collection, all_sku_operations, "SKU updates")
    execute_bulk_operations(cards_collection, card_operations, "card updates")
    
    return updated_skus, skipped_skus, updated_cards, newly_processed

def process_chunk(chunk_data):
    """Process a chunk of the CSV in a separate process"""
    try:
        # Create a new database connection for each process
        db = connect_to_mongodb()
        chunk = pd.DataFrame(chunk_data)
        updated_skus, skipped_skus, updated_cards, newly_processed = update_prices_from_chunk(chunk, db)
        return updated_skus, skipped_skus, updated_cards, newly_processed
    except Exception as e:
        print(f"Error in worker process: {e}")
        return 0, 0, 0, set()

def process_csv_in_batches(csv_path, skip_processed=False):
    """Process CSV file in batches and update prices in MongoDB"""
    print(f"Loading CSV: {csv_path}")
    
    # Start timing
    start_time = time.time()
    
    # Set up processed SKUs tracking
    processed_file = f"{os.path.splitext(csv_path)[0]}_processed.csv"
    processed_skus = None
    if skip_processed:
        processed_skus = load_processed_skus(processed_file)
    
    # Load checkpoint for resuming
    checkpoint = load_checkpoint()
    current_row = checkpoint["current_row"]
    processed_chunks = checkpoint["processed_chunks"]
    
    # Get total number of rows for progress tracking
    with open(csv_path, 'r') as f:
        total_rows = sum(1 for _ in f) - 1  # -1 for header
    
    if current_row > 0:
        print(f"Resuming from row {current_row}/{total_rows} (chunk {processed_chunks})")
    
    print(f"Total rows to process: {total_rows}")
    
    # Track overall stats
    total_skus_updated = 0
    total_cards_updated = 0
    
    # Determine number of CPU cores to use (leave 1 for system)
    cpu_count = max(1, multiprocessing.cpu_count() - 1)
    print(f"Using {cpu_count} CPU cores for parallel processing")
    
    # Read the CSV in chunks to save memory, skipping already processed rows
    chunksize = BATCH_SIZE
    skiprows = None
    if current_row > 0:
        skiprows = list(range(1, current_row + 1))  # Skip header and processed rows
    
    try:
        # Create a context manager for the multiprocessing pool
        with multiprocessing.Pool(processes=cpu_count) as pool:
            # Read the CSV in chunks
            for i, chunk in enumerate(pd.read_csv(csv_path, chunksize=chunksize, skiprows=skiprows)):
                chunk_num = i + processed_chunks
                chunk_start = time.time()
                
                print(f"\nProcessing chunk {chunk_num+1} (rows {current_row+1}-{current_row+len(chunk)})")
                
                if len(chunk) > 50:  # Only use multiprocessing for larger chunks
                    # Split chunk for multiprocessing
                    chunk_splits = np.array_split(chunk, min(cpu_count, len(chunk)//10 + 1))
                    
                    # Process chunk splits in parallel
                    results = pool.map(process_chunk, [chunk_data.to_dict('records') for chunk_data in chunk_splits])
                    
                    # Collect results
                    for skus_updated, skipped_skus, cards_updated, newly_processed in results:
                        if processed_skus is not None:
                            processed_skus.update(newly_processed)
                        total_skus_updated += skus_updated
                        total_cards_updated += cards_updated
                else:
                    # For small chunks, process directly
                    db = connect_to_mongodb()
                    skus_updated, skipped_skus, cards_updated, newly_processed = update_prices_from_chunk(
                        chunk, db, processed_skus
                    )
                    if processed_skus is not None:
                        processed_skus.update(newly_processed)
                    total_skus_updated += skus_updated
                    total_cards_updated += cards_updated
                
                # Update current position
                current_row += len(chunk)
                processed_chunks = chunk_num + 1
                
                # Save checkpoint after each chunk
                save_checkpoint(current_row, processed_chunks)
                
                # Save processed SKUs periodically
                if skip_processed and processed_skus and chunk_num % 5 == 0:
                    save_processed_skus(processed_skus, processed_file)
                
                # Log batch completion
                batch_time = time.time() - chunk_start
                rows_per_second = len(chunk) / batch_time
                print(f"Chunk {chunk_num+1}: Processed {len(chunk)} rows in {batch_time:.2f}s ({rows_per_second:.2f} rows/sec)")
                print(f"Progress: {current_row}/{total_rows} rows ({current_row/total_rows*100:.1f}%)")
                
                # Add a pause between chunks to reduce system load
                time.sleep(1)
                
    except KeyboardInterrupt:
        print("\nProcess interrupted by user. Saving progress...")
        save_checkpoint(current_row, processed_chunks)
        if skip_processed and processed_skus:
            save_processed_skus(processed_skus, processed_file)
        sys.exit(1)
    except Exception as e:
        print(f"\nError during processing: {e}")
        print("Saving progress before exiting...")
        save_checkpoint(current_row, processed_chunks)
        if skip_processed and processed_skus:
            save_processed_skus(processed_skus, processed_file)
        raise
    
    # Calculate total execution time
    total_time = time.time() - start_time
    
    print(f"\nUpdate summary:")
    print(f"- Processed rows: {current_row}")
    print(f"- Updated SKUs in allskus collection: {total_skus_updated}")
    print(f"- Updated cards in cards collection: {total_cards_updated}")
    print(f"- Total execution time: {total_time:.2f} seconds ({total_time/60:.2f} minutes)")
    print(f"- Average processing speed: {current_row/total_time:.2f} rows/second")

    # Save processed SKUs
    if skip_processed and processed_skus:
        save_processed_skus(processed_skus, processed_file)
    
    # Clear checkpoint after successful completion
    if os.path.exists(CHECKPOINT_FILE):
        os.remove(CHECKPOINT_FILE)
        print("Removed checkpoint file after successful completion")

def download_from_spaces(remote_file_path=None, local_file_path="english-prices.csv"):
    """Download file from DigitalOcean Spaces to local path"""
    if remote_file_path is None:
        remote_file_path = DO_SPACES_FILE_PATH
        
    print(f"Downloading file from DO Spaces: {remote_file_path} to {local_file_path}")
    
    # Check if required environment variables are set
    if not all([DO_SPACES_KEY, DO_SPACES_SECRET, DO_SPACES_BUCKET]):
        print("Error: Missing DigitalOcean Spaces configuration in .env file")
        print("Required: DO_SPACES_KEY, DO_SPACES_SECRET, DO_SPACES_BUCKET")
        sys.exit(1)
    
    try:
        # Create session
        session = boto3.session.Session()
        client = session.client('s3',
                               region_name=DO_SPACES_REGION,
                               endpoint_url=DO_SPACES_ENDPOINT,
                               aws_access_key_id=DO_SPACES_KEY,
                               aws_secret_access_key=DO_SPACES_SECRET)
        
        # Download the file
        client.download_file(DO_SPACES_BUCKET, remote_file_path, local_file_path)
        print(f"✅ Successfully downloaded file to {local_file_path}")
        return local_file_path
    except Exception as e:
        print(f"❌ Error downloading file from DO Spaces: {e}")
        sys.exit(1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Update prices from CSV file")
    parser.add_argument("--remote-path", 
                        help="Path to the CSV file in DO Spaces (default: from DO_SPACES_FILE_PATH env var)")
    parser.add_argument("--skip-processed", action="store_true", 
                      help="Skip SKUs that have been processed before")
    parser.add_argument("--reset-processed", action="store_true", 
                      help="Clear the list of processed SKUs")
    parser.add_argument("--reset-checkpoint", action="store_true",
                      help="Clear checkpoint and restart from beginning")
    parser.add_argument("--local-file", default="english-prices.csv",
                      help="Local file name to save the downloaded file (default: english-prices.csv)")
    args = parser.parse_args()
    
    # Download file from DO Spaces
    local_file_path = download_from_spaces(args.remote_path, args.local_file)
    
    if args.reset_processed:
        processed_file = f"{os.path.splitext(local_file_path)[0]}_processed.csv"
        if os.path.exists(processed_file):
            os.remove(processed_file)
            print(f"Reset processed SKUs by removing {processed_file}")
    
    if args.reset_checkpoint and os.path.exists(CHECKPOINT_FILE):
        os.remove(CHECKPOINT_FILE)
        print("Reset checkpoint file to start from beginning")
    
    skip_processed = args.skip_processed
    if skip_processed:
        print("Skipping SKUs that have been processed before")
    
    process_csv_in_batches(local_file_path, skip_processed)
