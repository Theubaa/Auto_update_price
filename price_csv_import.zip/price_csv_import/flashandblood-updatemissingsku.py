import pandas as pd
import pymongo
from pymongo import UpdateOne
import os
from dotenv import load_dotenv
import sys
import time
from botocore.client import Config
import boto3

# Load environment variables
load_dotenv()

# MongoDB connection settings
MONGO_URI = os.environ.get("MONGO_URI")
if not MONGO_URI:
    print("Error: MONGO_URI environment variable not set in .env file")
    sys.exit(1)

DB_NAME = os.environ.get("DB_NAME", "your_database_name")
CARDS_COLLECTION = "cards"

# DigitalOcean Spaces configuration (for downloading the CSV)
DO_SPACES_KEY = os.environ.get("DO_SPACES_KEY")
DO_SPACES_SECRET = os.environ.get("DO_SPACES_SECRET")
DO_SPACES_ENDPOINT = os.environ.get("DO_SPACES_ENDPOINT", "https://nyc3.digitaloceanspaces.com")
DO_SPACES_BUCKET = os.environ.get("DO_SPACES_BUCKET")
DO_SPACES_REGION = os.environ.get("DO_SPACES_REGION", "nyc3")
DO_SPACES_FILE_PATH = os.environ.get("DO_SPACES_FILE_PATH", "pricing/fleshandblood-english.csv")

def connect_to_mongodb():
    """Connect to MongoDB"""
    try:
        client = pymongo.MongoClient(
            MONGO_URI,
            connectTimeoutMS=30000,
            socketTimeoutMS=60000,
            serverSelectionTimeoutMS=30000,
            retryWrites=True
        )
        # Force a connection to verify it works
        client.admin.command('ismaster')
        print(f"✅ Successfully connected to MongoDB ({DB_NAME})")
        return client[DB_NAME]
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        sys.exit(1)

def download_from_spaces(remote_file_path=None, local_file_path="fleshandblood-english.csv", force_download=False):
    """Download file from DigitalOcean Spaces to local path, or use existing file if available"""
    
    # Check if file already exists locally
    if os.path.exists(local_file_path) and not force_download:
        print(f"✅ Using existing local file: {local_file_path}")
        return local_file_path
        
    # Otherwise download from DO Spaces
    if remote_file_path is None:
        remote_file_path = DO_SPACES_FILE_PATH
        
    print(f"Downloading file from DO Spaces: {remote_file_path} to {local_file_path}")
    
    # Check if required environment variables are set
    if not all([DO_SPACES_KEY, DO_SPACES_SECRET, DO_SPACES_BUCKET]):
        print("Error: Missing DigitalOcean Spaces configuration in .env file")
        print("Required: DO_SPACES_KEY, DO_SPACES_SECRET, DO_SPACES_BUCKET")
        sys.exit(1)
    
    try:
        # Create session
        session = boto3.session.Session()
        client = session.client('s3',
                               region_name=DO_SPACES_REGION,
                               endpoint_url=DO_SPACES_ENDPOINT,
                               aws_access_key_id=DO_SPACES_KEY,
                               aws_secret_access_key=DO_SPACES_SECRET)
        
        # Download the file
        client.download_file(DO_SPACES_BUCKET, remote_file_path, local_file_path)
        print(f"✅ Successfully downloaded file to {local_file_path}")
        return local_file_path
    except Exception as e:
        print(f"❌ Error downloading file from DO Spaces: {e}")
        sys.exit(1)

def find_and_update_missing_skus(csv_path, store_id="65a7bbad", category_id=62, limit=100):
    """
    Find cards without sku field and update them based on matching data from CSV
    """
    # Connect to MongoDB
    db = connect_to_mongodb()
    cards_collection = db[CARDS_COLLECTION]
    
    # Define the query for cards missing sku field
    query = {
        "sku": {"$exists": False},
        #"store": store_id,
        "categoryId": category_id
    }
    
    # Count total cards missing SKU
    total_cards_missing_sku = cards_collection.count_documents(query)
    print(f"Total cards missing SKU in collection: {total_cards_missing_sku}")
    
    # Find cards missing sku field (with limit)
    cards_needing_sku = list(cards_collection.find(query).limit(limit))
    
    if not cards_needing_sku:
        print(f"No cards found matching query: {query}")
        return
    
    print(f"Processing {len(cards_needing_sku)} out of {total_cards_missing_sku} cards missing the sku field")
    
    # Load the CSV file
    print(f"Loading CSV file: {csv_path}")
    try:
        # Add low_memory=False to handle mixed data types
        csv_data = pd.read_csv(csv_path, low_memory=False)
        print(f"Loaded {len(csv_data)} rows from CSV")
        
        # Print the actual CSV columns for reference
        print("CSV Columns available:", csv_data.columns.tolist())
    except Exception as e:
        print(f"Error loading CSV: {e}")
        return
    
    # Prepare bulk update operations
    bulk_operations = []
    matched_count = 0
    
    # Process each card without sku
    for card in cards_needing_sku:
        card_id = card.get('_id')
        
        # Extract card details for matching
        card_name = card.get('name', '')
        
        # Get set name from the setInfo array
        set_name = ""
        if 'setInfo' in card and isinstance(card['setInfo'], list) and len(card['setInfo']) > 0:
            set_name = card['setInfo'][0].get('name', '')
        
        # Fallback to card.set if setInfo is not available
        if not set_name and 'set' in card:
            set_name = card.get('set', '')
            
        card_condition = card.get('condi', '')
        card_number = card.get('num', '')
        card_rarity = card.get('rarity', '')
        card_price = card.get('cTCG')
        
        print(f"\nLooking for match for card: {card_name} | Set: {set_name} | Condition: {card_condition}")
        
        # Skip if card has no name or set
        if not card_name or not set_name:
            print(f"⚠️ Skipping card with missing name or set: {card_id}")
            continue
        
        # Define filters for matching against CSV - UPDATED TO MATCH ACTUAL CSV HEADERS
        # Start with basic filter that must match
        matches = csv_data[
            (csv_data['Product Name'].str.lower() == card_name.lower()) &
            (csv_data['Set Name'].str.lower() == set_name.lower())
        ]
        
        print(f"Found {len(matches)} initial matches by name and set")
        
        # If we have condition, filter further
        if card_condition and len(matches) > 1:
            condition_matches = matches[matches['Condition'].str.lower() == card_condition.lower()]
            if not condition_matches.empty:
                matches = condition_matches
                print(f"Narrowed to {len(matches)} matches after condition filter")
        
        # If we have price info, use that for further filtering
        if card_price and len(matches) > 1:
            # Allow for some price variation (within 5%)
            price_lower = card_price * 0.95
            price_upper = card_price * 1.05
            price_matches = matches[
                (matches['TCG Market Price'].astype(float) >= price_lower) & 
                (matches['TCG Market Price'].astype(float) <= price_upper)
            ]
            if not price_matches.empty:
                matches = price_matches
                print(f"Narrowed to {len(matches)} matches after price filter")
        
        # If we have card number, use that too
        if card_number and len(matches) > 1:
            number_matches = matches[matches['Number'] == card_number]
            if not number_matches.empty:
                matches = number_matches
                print(f"Narrowed to {len(matches)} matches after card number filter")
                
        # Check if we found a match
        if len(matches) == 1:
            # We have a single match - use this SKU
            sku = str(matches.iloc[0]['TCGplayer Id'])
            print(f"✅ Found exact match with SKU: {sku}")
            print(f"   Would update card {card_id} with SKU: {sku}")
            
            # Add update operation (COMMENTED OUT)
            bulk_operations.append(
                 UpdateOne(
                     {"_id": card_id},
                     {"$set": {"sku": sku}}
                 )
             )
            matched_count += 1
        elif len(matches) > 1:
            # Multiple matches - log and skip for now, or could use first match
            print(f"⚠️ Found {len(matches)} potential matches - skipping for manual review")
            print(f"First 3 potential SKUs: {matches['TCGplayer Id'].head(3).tolist()}")
            # Show more details about the first 3 matches for debugging
            print("Match details:")
            for i in range(min(3, len(matches))):
                match = matches.iloc[i]
                print(f"  {i+1}. SKU: {match['TCGplayer Id']}")
                print(f"     Name: {match['Product Name']}")
                print(f"     Set: {match['Set Name']}")
                print(f"     Condition: {match.get('Condition', 'N/A')}")
                print(f"     Price: {match.get('TCG Market Price', 'N/A')}")
                print(f"     Number: {match.get('Number', 'N/A')}")
        else:
            # No match found
            print(f"❌ No match found for {card_name}")
    
    # Execute bulk operations if any (COMMENTED OUT)
    if bulk_operations:
         try:
             result = cards_collection.bulk_write(bulk_operations, ordered=False)
             print(f"\nUpdated {result.modified_count} cards with SKU values")
         except Exception as e:
             print(f"Error performing bulk update: {e}")
    
    # Updated summary section
    print(f"\nSummary:")
    print(f"- Total cards missing SKU in collection: {total_cards_missing_sku}")
    print(f"- Cards processed in this run: {len(cards_needing_sku)}")
    print(f"- Cards matched: {matched_count}")
    print(f"- Cards that would be updated: {matched_count}")
    print(f"- Cards remaining without SKU: {total_cards_missing_sku - matched_count}")
    print(f"\nNOTE: No database updates were performed - this was a dry run.")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Update missing SKU fields in cards collection")
    parser.add_argument("--remote-path", 
                        help="Path to the CSV file in DO Spaces (default: from DO_SPACES_FILE_PATH env var)")
    parser.add_argument("--local-file", default="fleshandblood-english.csv",
                        help="Local file name to save the downloaded file (default: fleshandblood-english.csv)")
    parser.add_argument("--store-id", default="65a7bbad",
                        help="Store ID to filter cards (default: 65a7bbad)")
    parser.add_argument("--category-id", default=62, type=int,
                        help="Category ID to filter cards (default: 62)")
    parser.add_argument("--limit", default=100, type=int,
                        help="Maximum number of cards to process (default: 10)")
    parser.add_argument("--force-download", action="store_true",
                        help="Force download the file even if it exists locally")
    
    args = parser.parse_args()
    
    # Download file from DO Spaces, or use local if it exists
    local_file_path = download_from_spaces(
        args.remote_path, 
        args.local_file, 
        args.force_download
    )
    
    # Find and update missing SKUs
    find_and_update_missing_skus(
        local_file_path, 
        store_id=args.store_id, 
        category_id=args.category_id,
        limit=args.limit
    )
